﻿namespace DddInPractice.Logic
{
    public class SnackMachineRepository : Repository<SnackMachine>
    {
    }
}
