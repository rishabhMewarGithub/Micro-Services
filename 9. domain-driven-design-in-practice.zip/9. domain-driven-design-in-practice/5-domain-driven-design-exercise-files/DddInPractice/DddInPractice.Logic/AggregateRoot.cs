﻿namespace DddInPractice.Logic
{
    public abstract class AggregateRoot : Entity
    {
    }
}
