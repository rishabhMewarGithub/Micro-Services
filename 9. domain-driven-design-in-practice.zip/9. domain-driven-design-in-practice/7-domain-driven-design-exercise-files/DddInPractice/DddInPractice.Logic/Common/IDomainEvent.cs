﻿namespace DddInPractice.Logic.Common
{
    public interface IDomainEvent
    {
    }
}
