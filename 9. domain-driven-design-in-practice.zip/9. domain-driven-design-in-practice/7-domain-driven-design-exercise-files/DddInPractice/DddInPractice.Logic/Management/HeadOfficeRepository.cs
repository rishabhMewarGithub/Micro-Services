﻿using DddInPractice.Logic.Common;

namespace DddInPractice.Logic.Management
{
    public class HeadOfficeRepository : Repository<HeadOffice>
    {
    }
}
