﻿using DddInPractice.Logic.Common;

namespace DddInPractice.Logic.Atms
{
    public class AtmRepository : Repository<Atm>
    {
    }
}
