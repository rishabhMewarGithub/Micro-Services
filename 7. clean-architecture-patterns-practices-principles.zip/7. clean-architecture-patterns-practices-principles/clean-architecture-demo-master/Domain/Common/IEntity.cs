﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CleanArchitecture.Domain.Common
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
