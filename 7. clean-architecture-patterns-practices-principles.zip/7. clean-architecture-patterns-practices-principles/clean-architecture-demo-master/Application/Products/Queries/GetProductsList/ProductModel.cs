﻿namespace CleanArchitecture.Application.Products.Queries.GetProductsList
{
    public class ProductModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal UnitPrice { get; set; }
    }
}