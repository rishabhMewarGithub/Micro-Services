# Clean Architecture Demo
A sample app for my presentation on Clean Architecture: Patterns, Practices, and Principles 
