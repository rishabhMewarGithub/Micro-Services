﻿using System;

namespace Acl
{
    public class ProductSyncronizer
    {
        public void Sync()
        {
            Console.WriteLine("Sync products");
        }
    }
}