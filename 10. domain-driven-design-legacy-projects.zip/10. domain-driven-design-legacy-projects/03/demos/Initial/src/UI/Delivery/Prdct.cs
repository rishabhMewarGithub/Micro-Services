namespace PackageDelivery.Delivery
{
    public class Prdct
    {
        public int NMB_CM { get; set; }
        public string NM_CLM { get; set; }
        public string DSC_CLM { get; set; }
        public double WT { get; set; }
        public double WT_KG { get; set; }
    }
}
